import json
import os
import boto3  # type: ignore
import urllib.request
import urllib.parse
from datetime import datetime, timezone, timedelta

WEBHOOK_SECRET = os.environ["WEBHOOK_SECRET"]
BOT_TOKEN_SSM_PATH = os.environ["BOT_TOKEN_SSM_PATH"]
AUTHENTIK_ASG = os.environ["AUTHENTIK_ASG_NAME"]
NAT_ASG = os.environ["NAT_ASG_NAME"]
CADDY_ASG = os.environ["CADDY_ASG_NAME"]
ATLANTIS_ASG = os.environ["ATLANTIS_ASG_NAME"]
ALLOWED_CHAT_ID = os.environ["ALLOWED_CHAT_ID"]

_ssm = boto3.client("ssm")
_asg = boto3.client("autoscaling")
_ec2 = boto3.client("ec2")
_token_cache: dict = {}

ICT = timezone(timedelta(hours=7))

HELP_TEXT = """Infrastructure Manager

Authentik (auth.tylerops.dev)
  /authentik_up   — start instance
  /authentik_down — stop instance

NAT Instance (private subnet egress)
  /nat_up   — enable internet for private subnets
  /nat_down — disable NAT

Caddy (atlantis.tylerops.dev reverse proxy)
  /caddy_up   — start Caddy
  /caddy_down — stop Caddy

Atlantis (CI/CD)
  /atlantis_up   — start Atlantis
  /atlantis_down — stop Atlantis

Overview
  /status — current state of all services

Scheduled: scale-down 22:00 ICT | scale-up 06:00 ICT"""


def get_bot_token() -> str:
    if "token" not in _token_cache:
        resp = _ssm.get_parameter(Name=BOT_TOKEN_SSM_PATH, WithDecryption=True)
        _token_cache["token"] = resp["Parameter"]["Value"]
    return _token_cache["token"]


def send_message(chat_id: str, text: str) -> None:
    url = f"https://api.telegram.org/bot{get_bot_token()}/sendMessage"
    data = urllib.parse.urlencode({"chat_id": chat_id, "text": text}).encode()
    req = urllib.request.Request(url, data=data, method="POST")
    with urllib.request.urlopen(req, timeout=8):
        pass


def scale(asg_name: str, desired: int) -> bool:
    """Scale ASG to desired capacity. Returns True if changed, False if already at desired."""
    resp = _asg.describe_auto_scaling_groups(AutoScalingGroupNames=[asg_name])
    current = resp["AutoScalingGroups"][0]["DesiredCapacity"]
    if current == desired:
        return False
    _asg.update_auto_scaling_group(
        AutoScalingGroupName=asg_name,
        MinSize=desired,
        DesiredCapacity=desired,
    )
    return True


def _format_uptime(launch_time: datetime) -> str:
    delta = datetime.now(tz=timezone.utc) - launch_time
    h, rem = divmod(int(delta.total_seconds()), 3600)
    m = rem // 60
    if h:
        return f"{h}h {m}m"
    return f"{m}m"


def get_status() -> str:
    resp = _asg.describe_auto_scaling_groups(
        AutoScalingGroupNames=[AUTHENTIK_ASG, NAT_ASG, CADDY_ASG, ATLANTIS_ASG]
    )
    labels = {
        AUTHENTIK_ASG: "Authentik (auth.tylerops.dev)",
        NAT_ASG: "NAT (private subnet egress)",
        CADDY_ASG: "Caddy (atlantis.tylerops.dev proxy)",
        ATLANTIS_ASG: "Atlantis (CI/CD)",
    }

    # Collect all InService instance IDs across groups
    all_instance_ids = [
        i["InstanceId"]
        for g in resp["AutoScalingGroups"]
        for i in g["Instances"]
        if i["LifecycleState"] == "InService"
    ]

    # Fetch LaunchTime from EC2 in one call
    ec2_info: dict[str, dict] = {}
    if all_instance_ids:
        ec2_resp = _ec2.describe_instances(InstanceIds=all_instance_ids)
        for reservation in ec2_resp["Reservations"]:
            for inst in reservation["Instances"]:
                ec2_info[inst["InstanceId"]] = inst

    lines = ["Service Status\n"]
    for group in resp["AutoScalingGroups"]:
        name = group["AutoScalingGroupName"]
        desired = group["DesiredCapacity"]
        in_service = [i for i in group["Instances"] if i["LifecycleState"] == "InService"]
        running = len(in_service)

        if desired == 0:
            state = "stopped"
        elif running == desired:
            state = "running"
        else:
            state = f"starting ({running}/{desired} ready)"

        label = labels.get(name, name)
        block = f"{label}\n  {state}"

        if in_service:
            inst_id = in_service[0]["InstanceId"]
            instance_type = in_service[0].get("InstanceType", "?")
            ec2 = ec2_info.get(inst_id, {})
            launch_time = ec2.get("LaunchTime")
            if launch_time:
                launched_ict = launch_time.astimezone(ICT).strftime("%m-%d %H:%M ICT")
                block += f"\n  {instance_type} | up {_format_uptime(launch_time)} (since {launched_ict})"

        lines.append(block)

    return "\n\n".join(lines)


def handler(event, _context):
    headers = {k.lower(): v for k, v in event.get("headers", {}).items()}
    if headers.get("x-telegram-bot-api-secret-token") != WEBHOOK_SECRET:
        return {"statusCode": 403, "body": "Forbidden"}

    body = json.loads(event.get("body") or "{}")
    message = body.get("message") or body.get("edited_message") or {}
    if not message:
        return {"statusCode": 200, "body": "ok"}

    chat_id = str(message.get("chat", {}).get("id", ""))
    text = (message.get("text") or "").strip()

    if chat_id != ALLOWED_CHAT_ID or not text:
        return {"statusCode": 200, "body": "ok"}

    try:
        # Normalize "/nat_down" and "/nat down" → "nat_down"
        cmd = text.lower().strip().lstrip("/").split("@")[0].replace(" ", "_")

        if cmd == "authentik_up":
            changed = scale(AUTHENTIK_ASG, 1)
            if changed:
                send_message(chat_id, "Authentik: starting...\nReady in ~1-2 min at auth.tylerops.dev")
            else:
                send_message(chat_id, "Authentik: already running")
        elif cmd == "authentik_down":
            changed = scale(AUTHENTIK_ASG, 0)
            if changed:
                send_message(chat_id, "Authentik: stopping...\nauth.tylerops.dev will be unavailable")
            else:
                send_message(chat_id, "Authentik: already stopped")
        elif cmd == "nat_up":
            changed = scale(NAT_ASG, 1)
            if changed:
                send_message(chat_id, "NAT: starting...\nPrivate subnet egress available in ~1 min")
            else:
                send_message(chat_id, "NAT: already running")
        elif cmd == "nat_down":
            changed = scale(NAT_ASG, 0)
            if changed:
                send_message(chat_id, "NAT: stopping...\nPrivate subnet internet access disabled")
            else:
                send_message(chat_id, "NAT: already stopped")
        elif cmd == "caddy_up":
            changed = scale(CADDY_ASG, 1)
            if changed:
                send_message(chat_id, "Caddy: starting...\natlantis.tylerops.dev available in ~1 min")
            else:
                send_message(chat_id, "Caddy: already running")
        elif cmd == "caddy_down":
            changed = scale(CADDY_ASG, 0)
            if changed:
                send_message(chat_id, "Caddy: stopping...\natlantis.tylerops.dev will be unreachable")
            else:
                send_message(chat_id, "Caddy: already stopped")
        elif cmd == "atlantis_up":
            changed = scale(ATLANTIS_ASG, 1)
            if changed:
                send_message(chat_id, "Atlantis: starting...\nReady in ~1-2 min")
            else:
                send_message(chat_id, "Atlantis: already running")
        elif cmd == "atlantis_down":
            changed = scale(ATLANTIS_ASG, 0)
            if changed:
                send_message(chat_id, "Atlantis: stopping...")
            else:
                send_message(chat_id, "Atlantis: already stopped")
        elif cmd == "status":
            send_message(chat_id, get_status())
        elif cmd in ("help", "start"):
            send_message(chat_id, HELP_TEXT)
        else:
            send_message(chat_id, f"Unknown command.\n\n{HELP_TEXT}")

    except Exception as e:
        send_message(chat_id, f"Error: {e}")

    return {"statusCode": 200, "body": "ok"}
